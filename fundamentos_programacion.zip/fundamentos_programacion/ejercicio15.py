n1 = input("ingresa el numero1: ")
n2 = input("ingresa el numero2: ")
nx
