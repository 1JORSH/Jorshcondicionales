
"""
Ejercisio 1:
Escribir un programa que le pregunte al usuario su nombre e imprima un saludo
Entradas:
nombre: string
Salida:
saludo: string
"""
nombre = input("Escribe tu nombre:")
edad = ("Escribe tu nombre: /n")
saludo = "Hola" + nombre + "de" + edad + " años!"
print(saludo)


if edad > 10:
    print("Es grande!")
else:
  print("No es grande")