min = int(input("ingrese los minutos: "))
hora = min/60
minu = min % 60
print("las horas son: ",hora , minu)
