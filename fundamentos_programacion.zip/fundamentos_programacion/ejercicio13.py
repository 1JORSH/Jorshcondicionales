n1 = input("ingresa el numero: ")
n1 = int(n1)
rc = (n1)**1/2
print("la raiz cuadrada de este numero: ",rc)
rcub = (n1)**1/3
print("la raiz cubica de este numero: ",rcub)