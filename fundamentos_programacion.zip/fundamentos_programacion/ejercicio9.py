compra = input("ingrese la compra: ")
compra = int(compra)
descuento = compra * 15 / 100
print("el descuento de la compra es: ",descuento)
comprat = compra - descuento
print("la compra con descuento es: ",comprat)

