n1= input("escribe el n1: ")
n1 = int(n1)
n2 = input("escribe el n2: ")
n2 = int(n2)
suma = n1 + n2
print("la suma de los dos numeros son: ",suma)
resta = n1 - n2
print("la resta de los dos numeros son: ",resta)
multiplicacion = n1 * n2
print(" la multiplicacion de estos dos numeros: ",multiplicacion)
division = n1 / n2
print(" la division de estos dos numeros son: ",division)
