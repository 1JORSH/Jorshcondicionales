n1 = input("ingrese el numero: ")
n1 = int(n1)
dec = n1 // 10
print(dec)
uni= n1 % 10
print(uni)
ninv = uni*101+dec
print(ninv)
