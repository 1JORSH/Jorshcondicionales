gradosF = input("ingrese los grados farenheit: ")
gradosF = int(gradosF)
celsius = gradosF - 32 / 1.8
print("la conversion de farenheit a celsius es: ",celsius)
