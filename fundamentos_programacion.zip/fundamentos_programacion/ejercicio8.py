v1 = float(input("ingrese la venta: "))
v2 = float(input("ingrese la venta: "))
v3 = float(input("ingrese la venta: "))
sueldo_b = float(input("ingresa el sueldo base: "))
tv = v1 + v2 + v3
print("toltal de venta es: ",tv)
cm = tv * 0.1
sueldo_t = sueldo_b + cm
print("tu sueldo total es: ",sueldo_t)


