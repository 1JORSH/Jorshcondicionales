n1 = ("ingresar el numero1: ")
n1 = int(n1)
n2 = ("ingresar el numero2: ")
n2 = int(n2)
media = n1 + n2 + n3 /3
print("la media de estos numeros son: ",media)
